//
//  BarCloudSDK.h
//  BarCloudSDK
//
//  Created by Mister Grizzly on 4/4/19.
//  Copyright © 2019 Mister Grizzly. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BarCloudSDK.
FOUNDATION_EXPORT double BarCloudSDKVersionNumber;

//! Project version string for BarCloudSDK.
FOUNDATION_EXPORT const unsigned char BarCloudSDKVersionString[];

// In this header, you should import all the public headers of your
// framework using statements like #import <BarCloudSDK/PublicHeader.h>
